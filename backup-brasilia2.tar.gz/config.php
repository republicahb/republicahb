<?php return array (
  'components' => 
  array (
    'db' => 
    array (
      'dsn' => 'mysql:host=localhost;dbname=host_172409',
      'username' => 'host_172409',
      'password' => 'nzVEWjN',
      'charset' => 'utf8',
    ),
    'user' => 
    array (
    ),
    'mailer' => 
    array (
      'transport' => 
      array (
        'dsn' => 'native://default',
      ),
    ),
    'cache' => 
    array (
      'class' => 'yii\\caching\\FileCache',
      'keyPrefix' => '64b994f62c1eb',
    ),
    'formatter' => 
    array (
      'defaultTimeZone' => 'America/Sao_Paulo',
    ),
  ),
  'params' => 
  array (
    'installer' => 
    array (
      'db' => 
      array (
        'installer_hostname' => 'localhost',
        'installer_database' => 'host_172409',
      ),
    ),
    'settings' => 
    array (
      'baseUrl' => 'https://brasilia2.humhub.com',
      'file' => 
      array (
        'maxFileSize' => 16777216,
      ),
    ),
    'hosting' => 
    array (
      'id' => 172409,
      'max_users' => 3,
      'max_store' => 500,
      'server_id' => 219,
      'status' => 1,
      'name' => 'brasilia2',
      'last_usage' => '2023-07-21 16:16:29',
      'api_url' => 'https://www.humhub.org/hosting/api/',
      'plan' => 'free',
      'plan_title' => 'Free',
      'plan_description' => 'Max Users: 3 - Max Storage: 500 MB',
    ),
    'config_created_at' => 1689914392,
    'horImageScrollOnMobile' => '1',
    'databaseInstalled' => true,
    'installed' => true,
  ),
  'id' => '64b994f62c1eb',
  'name' => 'republicahb ',
  'language' => 'pt-BR',
  'timeZone' => 'America/Sao_Paulo',
); ?>