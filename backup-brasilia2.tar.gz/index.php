<?php

$humhubDir = '/srv/humhub';

require($humhubDir . '/protected/vendor/autoload.php');
require($humhubDir . '/protected/vendor/yiisoft/yii2/Yii.php');

# Merge Configs
$config = yii\helpers\ArrayHelper::merge(
        require('/srv/humhub/protected/humhub/config/common.php'),
        require('/srv/humhub/protected/humhub/config/web.php'),
        require('/srv/www/etc/humhub/common.php'),
        require('/srv/www/etc/humhub/web.php'),
        require(dirname(__FILE__) . '/config.php'),
        (is_file(dirname(__FILE__) . '/localconfig.php')) ? require(dirname(__FILE__) . '/localconfig.php') : [],
        (is_file(dirname(__FILE__) . '/localconfig-web.php')) ? require(dirname(__FILE__) . '/localconfig-web.php') : [],
);


# Set hosting aliases
Yii::setAlias('@webroot', dirname(__FILE__));
Yii::setAlias('@themes', '@webroot/themes');

(new humhub\components\Application($config))->run();
