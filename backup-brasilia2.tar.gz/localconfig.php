<?php 

/**
 * Add your local configuration into this files.
 * More information at: https://docs.humhub.com
 */
return array (

);
?>