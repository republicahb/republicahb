<style>
    body, html {
        height: 100%;
        margin: 0;
    }

    .login-container {
        background-image: url("<?= $this->theme->getBaseUrl(); ?>/img/login-bg.jpg");
        height: 100%;

        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
    }
</style>
