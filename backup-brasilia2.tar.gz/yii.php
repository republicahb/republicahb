#!/usr/bin/env php
<?php
/**
 * Console Application
 */
defined('YII_DEBUG') or define('YII_DEBUG', true);

// fcgi doesn't have STDIN and STDOUT defined by default
defined('STDIN') or define('STDIN', fopen('php://stdin', 'r'));
defined('STDOUT') or define('STDOUT', fopen('php://stdout', 'w'));

require('/srv/humhub/protected/vendor/autoload.php');
require('/srv/humhub/protected/vendor/yiisoft/yii2/Yii.php');

$config = yii\helpers\ArrayHelper::merge(
        require('/srv/humhub/protected/humhub/config/common.php'),
        require('/srv/humhub/protected/humhub/config/console.php'),
        require('/srv/www/etc/humhub/common.php'), 
        require('/srv/www/etc/humhub/console.php'),
        require(dirname(__FILE__) . '/config.php')
);

// Optional local configuration
// Required below config merging, because namespace loading!
$localConfigFile = dirname(__FILE__) . '/localconfig.php';
$localConfig = [];
if (is_file($localConfigFile)) {
        $localConfig = require($localConfigFile);
}
$config = yii\helpers\ArrayHelper::merge($config, $localConfig);


# Set hosting aliases
Yii::setAlias('@webroot', dirname(__FILE__));
Yii::setAlias('@webroot-static', '/srv/humhub/static');

$application = new humhub\components\console\Application($config);
$exitCode = $application->run();
exit($exitCode);
